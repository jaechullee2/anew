#!/bin/bash

str="AAABBBCCC"
echo ${str%B*C}
