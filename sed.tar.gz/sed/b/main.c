#!include <stdio.h>

int main(){
	print("Hello, world~!!");
	return 0;
}
